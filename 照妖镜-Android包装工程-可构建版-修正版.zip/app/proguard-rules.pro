# Keep WebView bridge methods when a future build enables shrinking.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
