# 手机端构建 APK

本压缩包是可以直接放进 GitHub 仓库的 Android 包装工程。

1. 在 GitHub 新建一个空仓库。
2. 用手机浏览器打开仓库，上传本压缩包解压后的全部文件（保持 `.github/workflows/build-apk.yml` 路径不变）。
3. 打开仓库的 **Actions**，选择 **Build Android APK**，点击 **Run workflow**。
4. 构建结束后，在该次运行的 **Artifacts** 下载 `zhaoyaojing-debug-apk`，里面就是 `app-debug.apk`。
5. 手机上的“文件管理器”找到 APK，选择“安装 APK”。

第一次打开 APK 会要求输入网站地址，例如 `http://192.168.1.100/` 或 `https://你的域名/`。

注意：这个 APK 只是 Android WebView 容器。你提供的原项目仍然需要按源码里的安装教程部署 PHP + MySQL + Apache/Nginx，否则 APK 没有 PHP 执行环境，无法独立运行整个网站。
