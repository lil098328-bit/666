# 照妖镜 Android 包装工程

这个工程把原来的 PHP + MySQL 网站封装进 Android WebView，支持：
- HTTP/HTTPS 网站地址
- JavaScript / DOM Storage / Cookie
- Android 摄像头、麦克风权限，用于网页端 WebRTC
- 网页文件选择与上传
- Android 返回键网页后退

## 重要
原始压缩包本身不是 Android 工程，PHP 页面不能直接在 APK 内执行。按照原项目安装教程，需要先准备 PHP 7.2+、MySQL 5.6+ 和 Apache/Nginx，并把源码部署到可访问的服务器。

## 构建
建议使用 Android Studio 或命令行：

```bash
gradle assembleDebug
```

构建成功的 APK：
`app/build/outputs/apk/debug/app-debug.apk`

首次启动时输入 PHP 网站地址即可。
